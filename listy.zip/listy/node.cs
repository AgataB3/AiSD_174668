﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy
{
    internal class node
    {
        public node next;
        public node prev;
        public node data;
    }
}
