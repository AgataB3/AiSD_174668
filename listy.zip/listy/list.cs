﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace listy
{
    internal class list
    {
        public node head;
        public node tail;
        public node count;
    }
}
