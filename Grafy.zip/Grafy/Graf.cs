﻿namespace Grafy
{
    internal class Graf
    {
        List<Node_G> sasiedzi;
    }
}
