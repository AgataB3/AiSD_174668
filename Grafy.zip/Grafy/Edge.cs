﻿namespace Grafy
{
    internal class Edge
    {
        NodeG1 start;
        NodeG1 end;
        int weight;
    }
}
