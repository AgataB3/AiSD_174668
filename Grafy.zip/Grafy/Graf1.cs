﻿namespace Grafy
{
    internal class Graf1
    {
        List<NodeG1> nodes = new List<NodeG1>();
        List<Edge> edges = new List<Edge>();
        List<Graf1> lista = new List<Graf1>();

        /*
        GrafG1(Edge k)
        {

        }

        int ileNowychWezlow(Edge k)
        {

        }
        void Add(Edge k)
        {

        }

        void Join(GrafG1 g1)
        {

        }
        */
    }
}
