﻿namespace Grafy
{
    internal class Node_G
    {
        List<Node_G> sasiedzi = new List<Node_G>();
        int data;

        Node_G(int liczba)
        {
            this.data = liczba;
        }

        public override string ToString()
        {
            return this.data.ToString();
        }
    }
}
