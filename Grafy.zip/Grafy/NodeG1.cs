﻿namespace Grafy
{
    internal class NodeG1
    {
        int data;
    }
}
