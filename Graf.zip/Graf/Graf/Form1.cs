namespace Graf
{
    public partial class Form1 : Form
    {
        private Graf graf;
        public Form1()
        {
            InitializeComponent();

            NodeG A = new NodeG(1);
            NodeG B = new NodeG(2);
            NodeG C = new NodeG(3);
            NodeG D = new NodeG(4);
            NodeG E = new NodeG(5);
            NodeG F = new NodeG(6);
            NodeG G = new NodeG(7);

            A.dodajSasiada(B);
            A.dodajSasiada(C);
            B.dodajSasiada(D);
            B.dodajSasiada(E);
            C.dodajSasiada(D);
            C.dodajSasiada(F);
            D.dodajSasiada(F);
            E.dodajSasiada(F);
            F.dodajSasiada(G);

            graf = new Graf();
            graf.dodajWezel(A);
            graf.dodajWezel(B);
            graf.dodajWezel(C);
            graf.dodajWezel(D);
            graf.dodajWezel(E);
            graf.dodajWezel(F);
            graf.dodajWezel(G);

            panelGraf.Paint += PanelGraf_Paint;
        }
        private void btnDFS_Click(object sender, EventArgs e)
        {
            NodeG startNode = graf.nodes.First();
            List<NodeG> odwiedzoneWezly = graf.DFS(startNode);

            textBoxDFS.Clear();
            textBoxDFS.Text = string.Join(" ", odwiedzoneWezly.Select(wezel => wezel.ToString()));
        }
        private void btnBFS_Click(object sender, EventArgs e)
        {
            NodeG startNode = graf.nodes.First();

            var odleglosci = graf.BFS(startNode);

            dataGridViewOdleglosci.Columns.Clear();
            dataGridViewOdleglosci.Rows.Clear();

            dataGridViewOdleglosci.Columns.Add("wezel", "W�ze�");
            dataGridViewOdleglosci.Columns.Add("odleglosc", "Odleg�o��");

            foreach (var para in odleglosci)
            {
                dataGridViewOdleglosci.Rows.Add(para.Key.ToString(), para.Value.ToString());
            }
        }
        private void PanelGraf_Paint(object sender, PaintEventArgs e)
        {
            // Rysowanie grafu
            RysujGraf(e.Graphics, graf);
        }
        private void RysujGraf(Graphics g, Graf graf)
        {
            // Pozycje w�z��w na panelu (przyk�adowo rozmieszczone)
            Dictionary<NodeG, Point> pozycjeWezlow = new Dictionary<NodeG, Point>();
            int panelWidth = panelGraf.Width;
            int panelHeight = panelGraf.Height;
            int promienWezla = 20;

            // Rozmieszczenie w�z��w w okr�gu (dla przyk�adu)
            int srodekX = panelWidth / 2;
            int srodekY = panelHeight / 2;
            int promienOkregu = Math.Min(panelWidth, panelHeight) / 3;

            int liczbaWezlow = graf.nodes.Count;
            for (int i = 0; i < liczbaWezlow; i++)
            {
                double kat = 2 * Math.PI * i / liczbaWezlow;
                int x = srodekX + (int)(promienOkregu * Math.Cos(kat)) - promienWezla / 2;
                int y = srodekY + (int)(promienOkregu * Math.Sin(kat)) - promienWezla / 2;

                pozycjeWezlow[graf.nodes[i]] = new Point(x, y);
            }

            // Rysowanie kraw�dzi
            Pen penKrawedz = new Pen(Color.Black, 2);
            foreach (NodeG wezel in graf.nodes)
            {
                foreach (NodeG sasiad in wezel.sasiedzi)
                {
                    Point p1 = pozycjeWezlow[wezel];
                    Point p2 = pozycjeWezlow[sasiad];
                    g.DrawLine(penKrawedz, p1, p2);
                }
            }

            // Rysowanie w�z��w
            Brush brushWezel = Brushes.LightBlue;
            Pen penWezel = new Pen(Color.Black, 2);
            Font font = new Font("Arial", 10);
            foreach (var para in pozycjeWezlow)
            {
                NodeG wezel = para.Key;
                Point pozycja = para.Value;
                Rectangle rect = new Rectangle(pozycja.X, pozycja.Y, promienWezla, promienWezla);

                g.FillEllipse(brushWezel, rect);
                g.DrawEllipse(penWezel, rect);

                // Rysowanie numeru w�z�a
                string text = wezel.ToString();
                SizeF textSize = g.MeasureString(text, font);
                PointF textPos = new PointF(
                    pozycja.X + (promienWezla - textSize.Width) / 2,
                    pozycja.Y + (promienWezla - textSize.Height) / 2);
                g.DrawString(text, font, Brushes.Black, textPos);
            }
        }
    }
}
