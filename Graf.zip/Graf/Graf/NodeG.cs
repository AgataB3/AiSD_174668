﻿namespace Graf
{
    public class NodeG
    {
        public List<NodeG> sasiedzi { get; set; }
        public int data { get; set; }

        public NodeG(int liczba)
        {
            sasiedzi = new List<NodeG>();
            this.data = liczba;
        }

        public void dodajSasiada(NodeG nodeG)
        {
            this.sasiedzi.Add(nodeG);
        }

        public override string ToString()
        {
            return this.data.ToString();
        }
    }
}
