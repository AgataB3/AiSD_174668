﻿namespace Graf
{
    public class Graf
    {
        public List<NodeG> nodes { get; set; }

        public Graf()
        {
            nodes = new List<NodeG>();
        }

        public void dodajWezel(NodeG nodeG)
        {
            nodes.Add(nodeG);
        }
        public List<NodeG> DFS(NodeG startNode)
        {
            List<NodeG> odwiedzone = new List<NodeG>();

            void DFSRekurencyjnie(NodeG node)
            {
                if (odwiedzone.Contains(node))
                    return;

                odwiedzone.Add(node);

                foreach (NodeG sasiad in node.sasiedzi)
                {
                    DFSRekurencyjnie(sasiad);
                }
            }

            DFSRekurencyjnie(startNode);

            return odwiedzone;
        }
        public Dictionary<NodeG, int> BFS(NodeG startNode)
        {
            // Słownik przechowujący odległości od startowego węzła
            Dictionary<NodeG, int> odleglosci = new Dictionary<NodeG, int>();

            // Kolejka do przeszukiwania BFS
            Queue<NodeG> kolejka = new Queue<NodeG>();
            kolejka.Enqueue(startNode);

            // Ustaw odległość początkowego węzła na 0
            odleglosci[startNode] = 0;

            // Przechodzenie po węzłach grafu
            while (kolejka.Count > 0)
            {
                NodeG aktualny = kolejka.Dequeue();

                foreach (NodeG sasiad in aktualny.sasiedzi)
                {
                    // Jeśli sąsiad nie został jeszcze odwiedzony
                    if (!odleglosci.ContainsKey(sasiad))
                    {
                        // Ustaw odległość sąsiada i dodaj go do kolejki
                        odleglosci[sasiad] = odleglosci[aktualny] + 1;
                        kolejka.Enqueue(sasiad);
                    }
                }
            }

            return odleglosci;
        }
    }
}
