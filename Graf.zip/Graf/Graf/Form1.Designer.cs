﻿namespace Graf
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelGraf = new Panel();
            btnDFS = new Button();
            textBoxDFS = new TextBox();
            dataGridViewOdleglosci = new DataGridView();
            btnBFS = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewOdleglosci).BeginInit();
            SuspendLayout();
            // 
            // panelGraf
            // 
            panelGraf.Location = new Point(25, 27);
            panelGraf.Name = "panelGraf";
            panelGraf.Size = new Size(400, 400);
            panelGraf.TabIndex = 0;
            // 
            // btnDFS
            // 
            btnDFS.Location = new Point(516, 60);
            btnDFS.Name = "btnDFS";
            btnDFS.Size = new Size(210, 55);
            btnDFS.TabIndex = 2;
            btnDFS.Text = "Lista odwiedzanych dla węzła 1";
            btnDFS.UseVisualStyleBackColor = true;
            btnDFS.Click += btnDFS_Click;
            // 
            // textBoxDFS
            // 
            textBoxDFS.Location = new Point(516, 27);
            textBoxDFS.Name = "textBoxDFS";
            textBoxDFS.Size = new Size(210, 27);
            textBoxDFS.TabIndex = 3;
            // 
            // dataGridViewOdleglosci
            // 
            dataGridViewOdleglosci.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewOdleglosci.Location = new Point(471, 121);
            dataGridViewOdleglosci.Name = "dataGridViewOdleglosci";
            dataGridViewOdleglosci.RowHeadersWidth = 51;
            dataGridViewOdleglosci.RowTemplate.Height = 29;
            dataGridViewOdleglosci.Size = new Size(296, 283);
            dataGridViewOdleglosci.TabIndex = 4;
            // 
            // btnBFS
            // 
            btnBFS.Location = new Point(516, 410);
            btnBFS.Name = "btnBFS";
            btnBFS.Size = new Size(203, 49);
            btnBFS.TabIndex = 5;
            btnBFS.Text = "Lista odległości dla węzła 1";
            btnBFS.UseVisualStyleBackColor = true;
            btnBFS.Click += btnBFS_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 503);
            Controls.Add(btnBFS);
            Controls.Add(dataGridViewOdleglosci);
            Controls.Add(textBoxDFS);
            Controls.Add(btnDFS);
            Controls.Add(panelGraf);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridViewOdleglosci).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelGraf;
        private Button btnDFS;
        private TextBox textBoxDFS;
        private DataGridView dataGridViewOdleglosci;
        private Button btnBFS;
    }
}
