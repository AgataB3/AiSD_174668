﻿namespace Graf
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelGraf = new Panel();
            btnBFS = new Button();
            btnDFS = new Button();
            textBoxDFS = new TextBox();
            dataGridViewOdleglosci = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewOdleglosci).BeginInit();
            SuspendLayout();
            // 
            // panelGraf
            // 
            panelGraf.Location = new Point(33, 59);
            panelGraf.Margin = new Padding(3, 2, 3, 2);
            panelGraf.Name = "panelGraf";
            panelGraf.Size = new Size(350, 300);
            panelGraf.TabIndex = 0;
            // 
            // btnBFS
            // 
            btnBFS.Location = new Point(454, 363);
            btnBFS.Margin = new Padding(3, 2, 3, 2);
            btnBFS.Name = "btnBFS";
            btnBFS.Size = new Size(178, 37);
            btnBFS.TabIndex = 5;
            btnBFS.Text = "Lista odległości dla węzła 1";
            btnBFS.UseVisualStyleBackColor = true;
            btnBFS.Click += btnBFS_Click;
            // 
            // btnDFS
            // 
            btnDFS.Location = new Point(454, 38);
            btnDFS.Margin = new Padding(3, 2, 3, 2);
            btnDFS.Name = "btnDFS";
            btnDFS.Size = new Size(184, 41);
            btnDFS.TabIndex = 2;
            btnDFS.Text = "Lista odwiedzanych dla węzła 1";
            btnDFS.UseVisualStyleBackColor = true;
            btnDFS.Click += btnDFS_Click;
            // 
            // textBoxDFS
            // 
            textBoxDFS.Location = new Point(454, 11);
            textBoxDFS.Margin = new Padding(3, 2, 3, 2);
            textBoxDFS.Name = "textBoxDFS";
            textBoxDFS.Size = new Size(184, 23);
            textBoxDFS.TabIndex = 3;
            // 
            // dataGridViewOdleglosci
            // 
            dataGridViewOdleglosci.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewOdleglosci.Location = new Point(416, 100);
            dataGridViewOdleglosci.Margin = new Padding(3, 2, 3, 2);
            dataGridViewOdleglosci.Name = "dataGridViewOdleglosci";
            dataGridViewOdleglosci.RowHeadersWidth = 51;
            dataGridViewOdleglosci.RowTemplate.Height = 29;
            dataGridViewOdleglosci.Size = new Size(254, 259);
            dataGridViewOdleglosci.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 411);
            Controls.Add(btnBFS);
            Controls.Add(dataGridViewOdleglosci);
            Controls.Add(textBoxDFS);
            Controls.Add(btnDFS);
            Controls.Add(panelGraf);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridViewOdleglosci).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelGraf;
        private Button btnDFS;
        private TextBox textBoxDFS;
        private DataGridView dataGridViewOdleglosci;
        private Button btnBFS;
    }
}
