﻿namespace sort
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            button1 = new Button();
            listBox2 = new ListBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            textBox1 = new TextBox();
            button6 = new Button();
            numericUpDown1 = new NumericUpDown();
            button7 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(35, 159);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(730, 49);
            listBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(35, 341);
            button1.Name = "button1";
            button1.Size = new Size(136, 71);
            button1.TabIndex = 1;
            button1.Text = "Sortowanie bąbelkowe";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(35, 249);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(730, 49);
            listBox2.TabIndex = 2;
            // 
            // button2
            // 
            button2.Location = new Point(177, 341);
            button2.Name = "button2";
            button2.Size = new Size(147, 71);
            button2.TabIndex = 3;
            button2.Text = "Sortowanie przez wstawianie";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(330, 341);
            button3.Name = "button3";
            button3.Size = new Size(147, 71);
            button3.TabIndex = 4;
            button3.Text = "Merge Sort";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(483, 341);
            button4.Name = "button4";
            button4.Size = new Size(141, 71);
            button4.TabIndex = 5;
            button4.Text = "Counting Sort";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(630, 341);
            button5.Name = "button5";
            button5.Size = new Size(135, 71);
            button5.TabIndex = 6;
            button5.Text = "Quick Sort";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(35, 22);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(289, 23);
            textBox1.TabIndex = 7;
            // 
            // button6
            // 
            button6.Location = new Point(100, 63);
            button6.Name = "button6";
            button6.Size = new Size(149, 51);
            button6.TabIndex = 8;
            button6.Text = "Konwertuj";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(502, 22);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(263, 23);
            numericUpDown1.TabIndex = 9;
            // 
            // button7
            // 
            button7.Location = new Point(553, 61);
            button7.Name = "button7";
            button7.Size = new Size(143, 53);
            button7.TabIndex = 10;
            button7.Text = "Generuj";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 301);
            label1.Name = "label1";
            label1.Size = new Size(96, 15);
            label1.TabIndex = 11;
            label1.Text = "Czas Sortowania:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(35, 141);
            label2.Name = "label2";
            label2.Size = new Size(125, 15);
            label2.TabIndex = 12;
            label2.Text = "Przed posortowaniem:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(35, 231);
            label3.Name = "label3";
            label3.Size = new Size(100, 15);
            label3.TabIndex = 13;
            label3.Text = "Po posortowaniu:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button7);
            Controls.Add(numericUpDown1);
            Controls.Add(button6);
            Controls.Add(textBox1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(listBox2);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Button button1;
        private ListBox listBox2;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private TextBox textBox1;
        private Button button6;
        private NumericUpDown numericUpDown1;
        private Button button7;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}