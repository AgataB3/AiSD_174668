using System;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace sort
{
    public partial class Form1 : Form
    {
        private int[] tablica = { 0 };

        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }

        String tab_to_string(int[] tablica)
        {
            string wynik = "";
            for (int i = 0; i < tablica.Length; i++)
            {
                wynik += tablica[i] + " ";
            }
            return wynik;
        }

        private void Sortowanie_babelkowe(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length - 1; i++)
            {
                for (int j = 0; j < tablica.Length - 1 - i; j++)
                {
                    if (tablica[j] > tablica[j + 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j + 1];
                        tablica[j + 1] = zm;
                    }
                }
            }
        }

        public static void Sortowanie_wstawianie(int[] tablica)
        {
            int n = tablica.Length;

            for (int i = 1; i < n; i++)
            {
                int key = tablica[i];
                int j = i - 1;

                while (j >= 0 && tablica[j] > key)
                {
                    tablica[j + 1] = tablica[j];
                    j--;
                }

                tablica[j + 1] = key;
            }
        }

        public static void MergeSort(int[] tablica, int lewy, int prawy)
        {
            if (lewy < prawy)
            {
                int srodek = (lewy + prawy) / 2;

                MergeSort(tablica, lewy, srodek);

                MergeSort(tablica, srodek + 1, prawy);

                Scal(tablica, lewy, srodek, prawy);
            }
        }

        public static void Scal(int[] tablica, int lewy, int srodek, int prawy)
        {
            int rozmiarLewej = srodek - lewy + 1;
            int rozmiarPrawej = prawy - srodek;

            int[] lewaTablica = new int[rozmiarLewej];
            int[] prawaTablica = new int[rozmiarPrawej];

            for (int i = 0; i < rozmiarLewej; i++)
                lewaTablica[i] = tablica[lewy + i];
            for (int j = 0; j < rozmiarPrawej; j++)
                prawaTablica[j] = tablica[srodek + 1 + j];

            int indeksLewy = 0, indeksPrawy = 0, indeksGlowny = lewy;

            while (indeksLewy < rozmiarLewej && indeksPrawy < rozmiarPrawej)
            {
                if (lewaTablica[indeksLewy] <= prawaTablica[indeksPrawy])
                {
                    tablica[indeksGlowny] = lewaTablica[indeksLewy];
                    indeksLewy++;
                }
                else
                {
                    tablica[indeksGlowny] = prawaTablica[indeksPrawy];
                    indeksPrawy++;
                }
                indeksGlowny++;
            }

            while (indeksLewy < rozmiarLewej)
            {
                tablica[indeksGlowny] = lewaTablica[indeksLewy];
                indeksLewy++;
                indeksGlowny++;
            }

            while (indeksPrawy < rozmiarPrawej)
            {
                tablica[indeksGlowny] = prawaTablica[indeksPrawy];
                indeksPrawy++;
                indeksGlowny++;
            }
        }


        private void CountingSort(int[] tablica)
        {
            int max = tablica.Max();
            int min = tablica.Min();
            int[] count = new int[max - min + 1];
            int[] output = new int[tablica.Length];

            for (int i = 0; i < tablica.Length; i++)
            {
                count[tablica[i] - min]++;
            }

            for (int i = 1; i < count.Length; i++)
            {
                count[i] += count[i - 1];
            }

            for (int i = tablica.Length - 1; i >= 0; i--)
            {
                output[count[tablica[i] - min] - 1] = tablica[i];
                count[tablica[i] - min]--;
            }

            for (int i = 0; i < tablica.Length; i++)
            {
                tablica[i] = output[i];
            }
        }

        private void QuickSort(int[] tablica, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(tablica, low, high);
                QuickSort(tablica, low, pi - 1);
                QuickSort(tablica, pi + 1, high);
            }
        }

        private int Partition(int[] tablica, int low, int high)
        {
            int pivot = tablica[high];
            int i = (low - 1);
            for (int j = low; j < high; j++)
            {
                if (tablica[j] < pivot)
                {
                    i++;
                    int temp = tablica[i];
                    tablica[i] = tablica[j];
                    tablica[j] = temp;
                }
            }
            int temp1 = tablica[i + 1];
            tablica[i + 1] = tablica[high];
            tablica[high] = temp1;
            return i + 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Sortowanie_babelkowe(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Sortowanie_wstawianie(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            MergeSort(tablica, 0, tablica.Length - 1);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            CountingSort(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            QuickSort(tablica, 0, tablica.Length - 1);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button6_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            string[] liczby = input.Split(' ');
            bool czyLiczby = true;
            foreach (string x in liczby)
            {
                if (!int.TryParse(x, out _))
                {
                    czyLiczby = false;
                    break;
                }
            }
            if (czyLiczby && liczby.Length > 0)
            {
                if (liczby.Length > 15) liczby = liczby.Take(15).ToArray();
                tablica = Array.ConvertAll(liczby, int.Parse);
                listBox1.Items.Clear();
                listBox1.Items.Add(tab_to_string(tablica));
            }
            else
            {
                MessageBox.Show("Wprowadzono niepoprawne dane. Wprowad� tylko cyfry oddzielone spacj�.", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            int rozmiar = (int)numericUpDown1.Value;
            if (rozmiar > 15) rozmiar = 15;
            tablica = new int[rozmiar];

            Random rand = new Random();
            for (int i = 0; i < rozmiar; i++)
            {
                tablica[i] = rand.Next(1, 101);
            }
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }
    }
}
