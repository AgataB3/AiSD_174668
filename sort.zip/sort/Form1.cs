using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace sort
{
    public partial class Form1 : Form
    {
        private int[] tablica = {0};

        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }

        String tab_to_string(int[] tablica)
        {
            string wynik = "";
            for (int i = 0; i < tablica.Length; i++)
            {
                wynik += tablica[i] + " ";
            }
            return wynik;
        }
        String tab_to_string_15(int[] tablica)
        {
            string wynik = "";
            if (tablica.Length <= 15)
            {
                for (int i = 0; i < tablica.Length; i++)
                {
                    wynik += tablica[i] + " ";
                }
            }
            else
            {
                for (int i = 0; i < 15; i++)
                {
                    wynik += tablica[i] + " ";
                }
            }
            return wynik;
        }

        private void Sortowanie_babelkowe(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length - 1; i++)
            {
                for (int j = 0; j < tablica.Length - 1 - i; j++)
                {
                    if (tablica[j] > tablica[j + 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j + 1];
                        tablica[j + 1] = zm;
                    }
                }
            }
        }

        int[] Sortowanie_wstawianie(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (tablica[j] < tablica[j - 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j - 1];
                        tablica[j - 1] = zm;
                    }
                }
            }
            return tablica;
        }

        public static void Scal(int[] tablica, int p, int q, int r)
        {
            int r1 = q - p + 1;
            int r2 = r - q;
            int[] t1 = new int[r1];
            int[] t2 = new int[r2];
            for (int a = 0; a < r1; a++)
            {
                t1[a] = tablica[p + a];
            }
            for (int b = 0; b < r2; ++b)
            {
                t2[b] = tablica[q + 1 + b];
            }
            int i = 0;
            int j = 0;
            int k = p;
            while (i < r1 && j < r2)
            {
                if (t1[i] <= t2[j])
                {
                    tablica[k] = t1[i];
                    i++;
                }
                else
                {
                    tablica[k] = t2[j];
                    j++;
                }
                k++;
            }
            while (i < r1)
            {
                tablica[k] = t1[i];
                i++;
                k++;
            }
            while (j < r2)
            {
                tablica[k] = t2[j];
                j++;
                k++;
            }
        }
        private static void MS(int[] tablica, int p, int r)
        {
            int q;
            if (p < r)
            {
                q = (p + r) / 2;
                MS(tablica, p, q);
                MS(tablica, q + 1, r);
                Scal(tablica, p, q, r);
            }
        }

        private void CountingSort(int[] tablica)
        {
            int max = tablica.Max();
            int min = tablica.Min();
            int range = max - min + 1;
            int[] count = new int[range];
            int[] output = new int[tablica.Length];

            for (int i = 0; i < tablica.Length; i++)
            {
                count[tablica[i] - min]++;
            }

            for (int i = 1; i < count.Length; i++)
            {
                count[i] += count[i - 1];
            }

            for (int i = tablica.Length - 1; i >= 0; i--)
            {
                output[count[tablica[i] - min] - 1] = tablica[i];
                count[tablica[i] - min]--;
            }

            for (int i = 0; i < tablica.Length; i++)
            {
                tablica[i] = output[i];
            }
        }

        private void QuickSort(int[] tablica, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(tablica, low, high);
                QuickSort(tablica, low, pi - 1);
                QuickSort(tablica, pi + 1, high);
            }
        }

        private int Partition(int[] tablica, int low, int high)
        {
            int pivot = tablica[high];
            int i = (low - 1);
            for (int j = low; j < high; j++)
            {
                if (tablica[j] < pivot)
                {
                    i++;
                    int temp = tablica[i];
                    tablica[i] = tablica[j];
                    tablica[j] = temp;
                }
            }
            int temp1 = tablica[i + 1];
            tablica[i + 1] = tablica[high];
            tablica[high] = temp1;
            return i + 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            Sortowanie_babelkowe(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string_15(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            tablica = Sortowanie_wstawianie(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string_15(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            MS(tablica, 0, tablica.Length - 1);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string_15(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            CountingSort(tablica);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string_15(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            QuickSort(tablica, 0, tablica.Length - 1);
            stopwatch.Stop();
            TimeSpan ts = stopwatch.Elapsed;
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string_15(tablica));
            label1.Text = $"Czas sortowania: {ts.TotalMilliseconds} ms";
        }
        private void button6_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            string[] liczby = input.Split(' ');
            tablica = Array.ConvertAll(liczby, int.Parse);
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }
        private void button7_Click(object sender, EventArgs e)
        {
            int rozmiar = (int)numericUpDown1.Value;
            tablica = new int[rozmiar];

            Random rand = new Random();
            for (int i = 0; i < rozmiar; i++)
            {
                tablica[i] = rand.Next(1, 101);
            }
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
