using System;
using System.Windows.Forms;

namespace sort
{
    public partial class Form1 : Form
    {
        private int[] tablica = { 5, 6, 4, 1, 2, 3 };

        public Form1()
        {
            InitializeComponent();
            // Wyswietl(tablica, listBox1);
            listBox1.Items.Clear();
            listBox1.Items.Add(tab_to_string(tablica));
        }

        /*
        private void Wyswietl(int[] tablica, ListBox listBox)
        {
            listBox.Items.Clear();
            for (int i = 0; i < tablica.Length; i++)
            {
                listBox.Items.Add(tablica[i]);
            }
        }
        */

        String tab_to_string(int[] tablica)
        {
            string wynik = "";
            for (int i = 0; i < tablica.Length; i++)
            {
                wynik += tablica[i] + " ";
            }
            return wynik;
        }

        private void Sortowanie_babelkowe(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length - 1; i++)
            {
                for (int j = 0; j < tablica.Length - 1 - i; j++)
                {
                    if (tablica[j] > tablica[j + 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j + 1];
                        tablica[j + 1] = zm;
                    }
                }
            }
        }

        int[] Sortowanie_wstawianie(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    if (tablica[j] < tablica[j - 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j - 1];
                        tablica[j - 1] = zm;
                    }
                }
            }
            return tablica;
        }

        /*
        int[] MS(int[] tablica, int p, int r)
        {
            if(p < r)
            {

            }
        }
        */

        private void button1_Click(object sender, EventArgs e)
        {
            Sortowanie_babelkowe(tablica);
            listBox2.Items.Clear();
            listBox2.Items.Add(tab_to_string(tablica));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Wyswietl(Sortowanie_wstawianie(tablica), listBox3);
            tablica = Sortowanie_wstawianie(tablica);
            listBox3.Items.Clear();
            listBox3.Items.Add(tab_to_string(tablica));
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
