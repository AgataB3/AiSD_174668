﻿namespace listy_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddFirst = new Button();
            btnAddLast = new Button();
            btnRemoveFirst = new Button();
            btnRemoveLast = new Button();
            txtDisplay = new TextBox();
            txtInput = new TextBox();
            label1 = new Label();
            count_display = new Label();
            treeView1 = new TreeView();
            BSTInput = new TextBox();
            btBSTInput = new Button();
            label2 = new Label();
            label3 = new Label();
            btPre = new Button();
            tBPre = new TextBox();
            tBIn = new TextBox();
            tBPost = new TextBox();
            btIn = new Button();
            btPost = new Button();
            BSTRemove = new TextBox();
            btBSTRemove = new Button();
            SuspendLayout();
            // 
            // btnAddFirst
            // 
            btnAddFirst.Location = new Point(32, 67);
            btnAddFirst.Name = "btnAddFirst";
            btnAddFirst.Size = new Size(160, 24);
            btnAddFirst.TabIndex = 0;
            btnAddFirst.Text = "Add First";
            btnAddFirst.UseVisualStyleBackColor = true;
            btnAddFirst.Click += btnAddFirst_Click;
            // 
            // btnAddLast
            // 
            btnAddLast.Location = new Point(198, 67);
            btnAddLast.Name = "btnAddLast";
            btnAddLast.Size = new Size(151, 22);
            btnAddLast.TabIndex = 1;
            btnAddLast.Text = "Add Last";
            btnAddLast.UseVisualStyleBackColor = true;
            btnAddLast.Click += btnAddLast_Click;
            // 
            // btnRemoveFirst
            // 
            btnRemoveFirst.Location = new Point(354, 67);
            btnRemoveFirst.Name = "btnRemoveFirst";
            btnRemoveFirst.Size = new Size(146, 22);
            btnRemoveFirst.TabIndex = 2;
            btnRemoveFirst.Text = "Remove First";
            btnRemoveFirst.UseVisualStyleBackColor = true;
            btnRemoveFirst.Click += btnRemoveFirst_Click;
            // 
            // btnRemoveLast
            // 
            btnRemoveLast.Location = new Point(510, 67);
            btnRemoveLast.Name = "btnRemoveLast";
            btnRemoveLast.Size = new Size(134, 24);
            btnRemoveLast.TabIndex = 3;
            btnRemoveLast.Text = "Remove Last";
            btnRemoveLast.UseVisualStyleBackColor = true;
            btnRemoveLast.Click += btnRemoveLast_Click;
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(32, 97);
            txtDisplay.Multiline = true;
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(612, 50);
            txtDisplay.TabIndex = 5;
            // 
            // txtInput
            // 
            txtInput.Location = new Point(32, 40);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(612, 23);
            txtInput.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 22);
            label1.Name = "label1";
            label1.Size = new Size(290, 15);
            label1.TabIndex = 7;
            label1.Text = "Wpisz liczbę a następnie kliknij Add First lub Add Last:";
            // 
            // count_display
            // 
            count_display.AutoSize = true;
            count_display.Location = new Point(32, 149);
            count_display.Name = "count_display";
            count_display.Size = new Size(114, 15);
            count_display.TabIndex = 8;
            count_display.Text = "Liczba elementów: 0";
            // 
            // treeView1
            // 
            treeView1.Location = new Point(198, 174);
            treeView1.Margin = new Padding(3, 2, 3, 2);
            treeView1.Name = "treeView1";
            treeView1.Size = new Size(592, 201);
            treeView1.TabIndex = 12;
            // 
            // BSTInput
            // 
            BSTInput.Location = new Point(35, 207);
            BSTInput.Margin = new Padding(3, 2, 3, 2);
            BSTInput.Name = "BSTInput";
            BSTInput.Size = new Size(158, 23);
            BSTInput.TabIndex = 13;
            // 
            // btBSTInput
            // 
            btBSTInput.Location = new Point(35, 234);
            btBSTInput.Margin = new Padding(3, 2, 3, 2);
            btBSTInput.Name = "btBSTInput";
            btBSTInput.Size = new Size(158, 38);
            btBSTInput.TabIndex = 14;
            btBSTInput.Text = "Dodaj do drzewka BST";
            btBSTInput.UseVisualStyleBackColor = true;
            btBSTInput.Click += btBSTInput_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(32, 2);
            label2.Name = "label2";
            label2.Size = new Size(79, 21);
            label2.TabIndex = 15;
            label2.Text = "List, Node";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(35, 174);
            label3.Name = "label3";
            label3.Size = new Size(89, 21);
            label3.TabIndex = 16;
            label3.Text = "BST, NodeT";
            // 
            // btPre
            // 
            btPre.Location = new Point(32, 402);
            btPre.Margin = new Padding(3, 2, 3, 2);
            btPre.Name = "btPre";
            btPre.Size = new Size(248, 24);
            btPre.TabIndex = 17;
            btPre.Text = "PreOrder";
            btPre.UseVisualStyleBackColor = true;
            btPre.Click += btPre_Click;
            // 
            // tBPre
            // 
            tBPre.Location = new Point(32, 379);
            tBPre.Margin = new Padding(3, 2, 3, 2);
            tBPre.Name = "tBPre";
            tBPre.Size = new Size(249, 23);
            tBPre.TabIndex = 20;
            // 
            // tBIn
            // 
            tBIn.Location = new Point(286, 379);
            tBIn.Margin = new Padding(3, 2, 3, 2);
            tBIn.Name = "tBIn";
            tBIn.Size = new Size(261, 23);
            tBIn.TabIndex = 1;
            // 
            // tBPost
            // 
            tBPost.Location = new Point(552, 379);
            tBPost.Margin = new Padding(3, 2, 3, 2);
            tBPost.Name = "tBPost";
            tBPost.Size = new Size(238, 23);
            tBPost.TabIndex = 0;
            // 
            // btIn
            // 
            btIn.Location = new Point(286, 402);
            btIn.Margin = new Padding(3, 2, 3, 2);
            btIn.Name = "btIn";
            btIn.Size = new Size(261, 24);
            btIn.TabIndex = 21;
            btIn.Text = "InOrder";
            btIn.UseVisualStyleBackColor = true;
            btIn.Click += btIn_Click;
            // 
            // btPost
            // 
            btPost.Location = new Point(552, 402);
            btPost.Margin = new Padding(3, 2, 3, 2);
            btPost.Name = "btPost";
            btPost.Size = new Size(237, 24);
            btPost.TabIndex = 22;
            btPost.Text = "PostOrder";
            btPost.UseVisualStyleBackColor = true;
            btPost.Click += btPost_Click;
            // 
            // BSTRemove
            // 
            BSTRemove.Location = new Point(35, 287);
            BSTRemove.Name = "BSTRemove";
            BSTRemove.Size = new Size(158, 23);
            BSTRemove.TabIndex = 23;
            // 
            // btBSTRemove
            // 
            btBSTRemove.Location = new Point(35, 316);
            btBSTRemove.Name = "btBSTRemove";
            btBSTRemove.Size = new Size(158, 42);
            btBSTRemove.TabIndex = 24;
            btBSTRemove.Text = "Usuń element o podanej wartości";
            btBSTRemove.UseVisualStyleBackColor = true;
            btBSTRemove.Click += btBSTRemove_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btBSTRemove);
            Controls.Add(BSTRemove);
            Controls.Add(btPost);
            Controls.Add(btIn);
            Controls.Add(tBPost);
            Controls.Add(tBIn);
            Controls.Add(tBPre);
            Controls.Add(btPre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btBSTInput);
            Controls.Add(BSTInput);
            Controls.Add(treeView1);
            Controls.Add(count_display);
            Controls.Add(label1);
            Controls.Add(txtInput);
            Controls.Add(txtDisplay);
            Controls.Add(btnRemoveLast);
            Controls.Add(btnRemoveFirst);
            Controls.Add(btnAddLast);
            Controls.Add(btnAddFirst);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddFirst;
        private Button btnAddLast;
        private Button btnRemoveFirst;
        private Button btnRemoveLast;
        private TextBox txtDisplay;
        private TextBox txtInput;
        private Label label1;
        private Label count_display;
        private TreeView treeView1;
        private TextBox BSTInput;
        private Button btBSTInput;
        private Label label2;
        private Label label3;
        private Button btPre;
        private TextBox tBPre;
        private TextBox tBIn;
        private TextBox tBPost;
        private Button btIn;
        private Button btPost;
        private TextBox BSTRemove;
        private Button btBSTRemove;
    }
}
