﻿namespace listy_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddFirst = new Button();
            btnAddLast = new Button();
            btnRemoveFirst = new Button();
            btnRemoveLast = new Button();
            txtDisplay = new TextBox();
            txtInput = new TextBox();
            label1 = new Label();
            count_display = new Label();
            listBox1 = new ListBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // btnAddFirst
            // 
            btnAddFirst.Location = new Point(32, 146);
            btnAddFirst.Name = "btnAddFirst";
            btnAddFirst.Size = new Size(160, 61);
            btnAddFirst.TabIndex = 0;
            btnAddFirst.Text = "Add First";
            btnAddFirst.UseVisualStyleBackColor = true;
            btnAddFirst.Click += btnAddFirst_Click;
            // 
            // btnAddLast
            // 
            btnAddLast.Location = new Point(211, 149);
            btnAddLast.Name = "btnAddLast";
            btnAddLast.Size = new Size(151, 58);
            btnAddLast.TabIndex = 1;
            btnAddLast.Text = "Add Last";
            btnAddLast.UseVisualStyleBackColor = true;
            btnAddLast.Click += btnAddLast_Click;
            // 
            // btnRemoveFirst
            // 
            btnRemoveFirst.Location = new Point(381, 149);
            btnRemoveFirst.Name = "btnRemoveFirst";
            btnRemoveFirst.Size = new Size(146, 58);
            btnRemoveFirst.TabIndex = 2;
            btnRemoveFirst.Text = "Remove First";
            btnRemoveFirst.UseVisualStyleBackColor = true;
            btnRemoveFirst.Click += btnRemoveFirst_Click;
            // 
            // btnRemoveLast
            // 
            btnRemoveLast.Location = new Point(547, 149);
            btnRemoveLast.Name = "btnRemoveLast";
            btnRemoveLast.Size = new Size(134, 58);
            btnRemoveLast.TabIndex = 3;
            btnRemoveLast.Text = "Remove Last";
            btnRemoveLast.UseVisualStyleBackColor = true;
            btnRemoveLast.Click += btnRemoveLast_Click;
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(32, 233);
            txtDisplay.Multiline = true;
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(649, 62);
            txtDisplay.TabIndex = 5;
            // 
            // txtInput
            // 
            txtInput.Location = new Point(32, 101);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(649, 23);
            txtInput.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(32, 83);
            label1.Name = "label1";
            label1.Size = new Size(290, 15);
            label1.TabIndex = 7;
            label1.Text = "Wpisz liczbę a następnie kliknij Add First lub Add Last:";
            // 
            // count_display
            // 
            count_display.AutoSize = true;
            count_display.Location = new Point(32, 298);
            count_display.Name = "count_display";
            count_display.Size = new Size(114, 15);
            count_display.TabIndex = 8;
            count_display.Text = "Liczba elementów: 0";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(234, 311);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(438, 124);
            listBox1.TabIndex = 10;
            // 
            // button1
            // 
            button1.Location = new Point(36, 333);
            button1.Name = "button1";
            button1.Size = new Size(172, 60);
            button1.TabIndex = 11;
            button1.Text = "BST";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Controls.Add(count_display);
            Controls.Add(label1);
            Controls.Add(txtInput);
            Controls.Add(txtDisplay);
            Controls.Add(btnRemoveLast);
            Controls.Add(btnRemoveFirst);
            Controls.Add(btnAddLast);
            Controls.Add(btnAddFirst);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddFirst;
        private Button btnAddLast;
        private Button btnRemoveFirst;
        private Button btnRemoveLast;
        private TextBox txtDisplay;
        private TextBox txtInput;
        private Label label1;
        private Label count_display;
        private ListBox listBox1;
        private Button button1;
    }
}
