﻿namespace listy_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAddFirst = new Button();
            btnAddLast = new Button();
            btnRemoveFirst = new Button();
            btnRemoveLast = new Button();
            txtDisplay = new TextBox();
            txtInput = new TextBox();
            label1 = new Label();
            count_display = new Label();
            treeView1 = new TreeView();
            BSTInput = new TextBox();
            btBSTInput = new Button();
            label2 = new Label();
            label3 = new Label();
            btPre = new Button();
            tBPre = new TextBox();
            tBIn = new TextBox();
            tBPost = new TextBox();
            btIn = new Button();
            btPost = new Button();
            SuspendLayout();
            // 
            // btnAddFirst
            // 
            btnAddFirst.Location = new Point(37, 89);
            btnAddFirst.Margin = new Padding(3, 4, 3, 4);
            btnAddFirst.Name = "btnAddFirst";
            btnAddFirst.Size = new Size(183, 32);
            btnAddFirst.TabIndex = 0;
            btnAddFirst.Text = "Add First";
            btnAddFirst.UseVisualStyleBackColor = true;
            btnAddFirst.Click += btnAddFirst_Click;
            // 
            // btnAddLast
            // 
            btnAddLast.Location = new Point(226, 89);
            btnAddLast.Margin = new Padding(3, 4, 3, 4);
            btnAddLast.Name = "btnAddLast";
            btnAddLast.Size = new Size(173, 30);
            btnAddLast.TabIndex = 1;
            btnAddLast.Text = "Add Last";
            btnAddLast.UseVisualStyleBackColor = true;
            btnAddLast.Click += btnAddLast_Click;
            // 
            // btnRemoveFirst
            // 
            btnRemoveFirst.Location = new Point(405, 89);
            btnRemoveFirst.Margin = new Padding(3, 4, 3, 4);
            btnRemoveFirst.Name = "btnRemoveFirst";
            btnRemoveFirst.Size = new Size(167, 30);
            btnRemoveFirst.TabIndex = 2;
            btnRemoveFirst.Text = "Remove First";
            btnRemoveFirst.UseVisualStyleBackColor = true;
            btnRemoveFirst.Click += btnRemoveFirst_Click;
            // 
            // btnRemoveLast
            // 
            btnRemoveLast.Location = new Point(583, 89);
            btnRemoveLast.Margin = new Padding(3, 4, 3, 4);
            btnRemoveLast.Name = "btnRemoveLast";
            btnRemoveLast.Size = new Size(153, 32);
            btnRemoveLast.TabIndex = 3;
            btnRemoveLast.Text = "Remove Last";
            btnRemoveLast.UseVisualStyleBackColor = true;
            btnRemoveLast.Click += btnRemoveLast_Click;
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(37, 129);
            txtDisplay.Margin = new Padding(3, 4, 3, 4);
            txtDisplay.Multiline = true;
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(699, 66);
            txtDisplay.TabIndex = 5;
            // 
            // txtInput
            // 
            txtInput.Location = new Point(37, 54);
            txtInput.Margin = new Padding(3, 4, 3, 4);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(699, 27);
            txtInput.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(37, 30);
            label1.Name = "label1";
            label1.Size = new Size(367, 20);
            label1.TabIndex = 7;
            label1.Text = "Wpisz liczbę a następnie kliknij Add First lub Add Last:";
            // 
            // count_display
            // 
            count_display.AutoSize = true;
            count_display.Location = new Point(37, 199);
            count_display.Name = "count_display";
            count_display.Size = new Size(144, 20);
            count_display.TabIndex = 8;
            count_display.Text = "Liczba elementów: 0";
            // 
            // treeView1
            // 
            treeView1.Location = new Point(226, 232);
            treeView1.Name = "treeView1";
            treeView1.Size = new Size(676, 267);
            treeView1.TabIndex = 12;
            // 
            // BSTInput
            // 
            BSTInput.Location = new Point(40, 322);
            BSTInput.Name = "BSTInput";
            BSTInput.Size = new Size(180, 27);
            BSTInput.TabIndex = 13;
            // 
            // btBSTInput
            // 
            btBSTInput.Location = new Point(40, 355);
            btBSTInput.Name = "btBSTInput";
            btBSTInput.Size = new Size(180, 51);
            btBSTInput.TabIndex = 14;
            btBSTInput.Text = "Dodaj do drzewka BST";
            btBSTInput.UseVisualStyleBackColor = true;
            btBSTInput.Click += btBSTInput_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(37, 2);
            label2.Name = "label2";
            label2.Size = new Size(99, 28);
            label2.TabIndex = 15;
            label2.Text = "List, Node";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(40, 232);
            label3.Name = "label3";
            label3.Size = new Size(112, 28);
            label3.TabIndex = 16;
            label3.Text = "BST, NodeT";
            // 
            // btPre
            // 
            btPre.Location = new Point(37, 536);
            btPre.Name = "btPre";
            btPre.Size = new Size(284, 32);
            btPre.TabIndex = 17;
            btPre.Text = "PreOrder";
            btPre.UseVisualStyleBackColor = true;
            btPre.Click += btPre_Click;
            // 
            // tBPre
            // 
            tBPre.Location = new Point(37, 505);
            tBPre.Name = "tBPre";
            tBPre.Size = new Size(284, 27);
            tBPre.TabIndex = 20;
            // 
            // tBIn
            // 
            tBIn.Location = new Point(327, 505);
            tBIn.Name = "tBIn";
            tBIn.Size = new Size(298, 27);
            tBIn.TabIndex = 1;
            // 
            // tBPost
            // 
            tBPost.Location = new Point(631, 505);
            tBPost.Name = "tBPost";
            tBPost.Size = new Size(271, 27);
            tBPost.TabIndex = 0;
            // 
            // btIn
            // 
            btIn.Location = new Point(327, 536);
            btIn.Name = "btIn";
            btIn.Size = new Size(298, 32);
            btIn.TabIndex = 21;
            btIn.Text = "InOrder";
            btIn.UseVisualStyleBackColor = true;
            btIn.Click += btIn_Click;
            // 
            // btPost
            // 
            btPost.Location = new Point(631, 536);
            btPost.Name = "btPost";
            btPost.Size = new Size(271, 32);
            btPost.TabIndex = 22;
            btPost.Text = "PostOrder";
            btPost.UseVisualStyleBackColor = true;
            btPost.Click += btPost_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(btPost);
            Controls.Add(btIn);
            Controls.Add(tBPost);
            Controls.Add(tBIn);
            Controls.Add(tBPre);
            Controls.Add(btPre);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btBSTInput);
            Controls.Add(BSTInput);
            Controls.Add(treeView1);
            Controls.Add(count_display);
            Controls.Add(label1);
            Controls.Add(txtInput);
            Controls.Add(txtDisplay);
            Controls.Add(btnRemoveLast);
            Controls.Add(btnRemoveFirst);
            Controls.Add(btnAddLast);
            Controls.Add(btnAddFirst);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAddFirst;
        private Button btnAddLast;
        private Button btnRemoveFirst;
        private Button btnRemoveLast;
        private TextBox txtDisplay;
        private TextBox txtInput;
        private Label label1;
        private Label count_display;
        private TreeView treeView1;
        private TextBox BSTInput;
        private Button btBSTInput;
        private Label label2;
        private Label label3;
        private Button btPre;
        private TextBox tBPre;
        private TextBox tBIn;
        private TextBox tBPost;
        private Button btIn;
        private Button btPost;
    }
}
