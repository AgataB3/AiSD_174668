﻿namespace listy_1
{
    internal class List
    {
        public Node Head { get; private set; }
        private Node tail;
        private int count;

        public List()
        {
            Head = null;
            tail = null;
            count = 0;
        }

        public int Count
        {
            get { return count; }
        }

        public void AddFirst(Node newNode)
        {
            if (Head == null)
            {
                Head = newNode;
                tail = newNode;
            }
            else
            {
                newNode.Next = Head;
                Head.Prev = newNode;
                Head = newNode;
            }
            count++;
        }

        public void AddLast(Node newNode)
        {
            if (tail == null)
            {
                Head = newNode;
                tail = newNode;
            }
            else
            {
                tail.Next = newNode;
                newNode.Prev = tail;
                tail = newNode;
            }
            count++;
        }

        public void RemoveFirst()
        {
            if (Head == null) return;

            if (Head == tail)
            {
                Head = null;
                tail = null;
            }
            else
            {
                Head = Head.Next;
                Head.Prev = null;
            }
            count--;
        }

        public void RemoveLast()
        {
            if (tail == null) return;

            if (Head == tail)
            {
                Head = null;
                tail = null;
            }
            else
            {
                tail = tail.Prev;
                tail.Next = null;
            }
            count--;
        }
    }
}
