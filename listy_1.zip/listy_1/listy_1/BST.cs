﻿namespace listy_1
{
    public class BST
    {
        public NodeT root;

        public BST()
        {
            root = null;
        }

        public void Add(int liczba)
        {
            if (root == null)
            {
                root = new NodeT(liczba);
            }
            else if (liczba < root.data)
            {
                NodeT zm = root;
                root.lewe = new NodeT(liczba);
                root.rodzic = zm;

            }
            else if (liczba > root.data)
            {
                NodeT zm = root;
                root.prawe = new NodeT(liczba);
                root.rodzic = zm;
            }
        }
        public List<int> wyswietl()
        {
            List<int> wynik = new List<int>();
            lista(root, wynik);
            return wynik;
        }

        private void lista(NodeT nodeT, List<int> result)
        {
            if (nodeT != null)
            {
                lista(nodeT.lewe, result);
                result.Add(nodeT.data);
                lista(nodeT.prawe, result);
                result.Add(nodeT.data);
            }
        }
    }
}
