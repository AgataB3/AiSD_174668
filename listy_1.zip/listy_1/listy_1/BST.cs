﻿using System.Security.Cryptography;

namespace listy_1
{
    public class BST
    {
        public NodeT root;

        public BST()
        {
            root = null;
        }

        public void Add(int liczba)
        {
            var dziecko = new NodeT(liczba);
            if (this.root == null)
            {
                this.root = dziecko;
                return;
            }
            var rodzic = this.SzukajRodzica(dziecko);
            dziecko.rodzic = rodzic;
            if (rodzic.data > dziecko.data) rodzic.lewe = dziecko;
            else rodzic.prawe = dziecko;
        }

        public NodeT SzukajRodzica(NodeT dziecko)
        {
            var tmp = this.root;
            while (true)
            {
                if (tmp.data > dziecko.data)
                {
                    if (tmp.lewe == null) return tmp;
                    else tmp = tmp.lewe;
                }
                else
                {
                    if (tmp.prawe == null) return tmp;
                    else tmp = tmp.prawe;
                }
            }
        }

        public List<int> wyswietl()
        {
            List<int> wynik = new List<int>();
            lista(root, wynik);
            return wynik;
        }

        private void lista(NodeT nodeT, List<int> result)
        {
            if (nodeT != null)
            {
                lista(nodeT.lewe, result);
                result.Add(nodeT.data);
                lista(nodeT.prawe, result);
                result.Add(nodeT.data);
            }
        }
    }
}
