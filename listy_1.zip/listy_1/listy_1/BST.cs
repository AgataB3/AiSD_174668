﻿using System.Xml.Linq;

namespace listy_1
{
    public class BST
    {
        public NodeT root;

        public BST()
        {
            root = null;
        }

        public void Add(int liczba)
        {
            var dziecko = new NodeT(liczba);
            if (this.root == null)
            {
                this.root = dziecko;
                return;
            }
            var rodzic = this.SzukajRodzica(dziecko);
            dziecko.rodzic = rodzic;
            if (rodzic.data > dziecko.data) rodzic.lewe = dziecko;
            else rodzic.prawe = dziecko;
        }

        public NodeT SzukajRodzica(NodeT dziecko)
        {
            var tmp = this.root;
            while (true)
            {
                if (tmp.data > dziecko.data)
                {
                    if (tmp.lewe == null) return tmp;
                    else tmp = tmp.lewe;
                }
                else
                {
                    if (tmp.prawe == null) return tmp;
                    else tmp = tmp.prawe;
                }
            }
        }


        public int liczbaDzieci(NodeT nodeT)
        {
            int wynik = 0;
            if (nodeT.lewe != null) wynik++;
            if (nodeT.prawe != null) wynik++;
            return wynik;
        }

        public void RemoveElement(NodeT n)
        {
            if(n == null) return;
            int dzieci = liczbaDzieci(n);
            if(dzieci == 0)
            {
                if (n == root) root = null;
                else RemoveElement0(n);
            }
            else if(dzieci == 1)
            {
                NodeT dziecko = RemoveElement1(n);
                Replace(n, dziecko);
            }
            else if (dzieci == 2)
            {
                var nastepnik = Min(n.prawe);
                n.data = nastepnik.data;
                RemoveElement(nastepnik);
            }
            n.rodzic = null;
            n.lewe = null;
            n.prawe = null;
        }


        public void RemoveElement0(NodeT n)
        {
            if (n.rodzic == null) this.root = null;
            else if (n.rodzic.lewe == n) n.rodzic.lewe = null;
            else if (n.rodzic.prawe == n) n.rodzic.prawe = null;
            n.rodzic = null;
        }
        
        public NodeT RemoveElement1(NodeT n)
        {
            NodeT dziecko = null;
            if (n.lewe != null)
            {
                dziecko = n.lewe;
                this.RemoveElement0(dziecko);
            }
            else if(n.prawe != null)
            {
                dziecko = n.prawe;
                this.RemoveElement0(dziecko);
            }
            return dziecko;
        }

        public void Replace(NodeT n, NodeT dziecko)
        {
            if (n.rodzic == null)
            {
                this.root = dziecko;
            }
            else if (n.rodzic.lewe == n)
            {
                n.rodzic.lewe = dziecko;
            }
            else
            {
                n.rodzic.prawe = dziecko;
            }

            if (dziecko != null)
            {
                dziecko.rodzic = n.rodzic;
            }
        }


        public NodeT Min(NodeT n)
        {
            var tmp = n;
            while (tmp.lewe != null) tmp = tmp.lewe;
            return tmp;
        }
    }
}
