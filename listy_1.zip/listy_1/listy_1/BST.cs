﻿namespace listy_1
{
    public class BST
    {
        public NodeT root;

        void Add(int liczba)
        {

        }
    }
}
