using System.Text;

namespace listy_1
{
    public partial class Form1 : Form
    {
        private List myList;

        public Form1()
        {
            InitializeComponent();
            myList = new List();
        }

        // Dodaje nowy w�ze� na pocz�tku listy
        private void btnAddFirst_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value)) // Sprawdzanie warto�ci
            {
                Node newNode = new Node(value); // Tworzenie nowego w�z�a z warto�ci�
                myList.AddFirst(newNode);
                txtInput.Clear(); // Czy�cimy pole tekstowe
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnAddLast_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value)) // Sprawdzanie warto�ci
            {
                Node newNode = new Node(value); // Tworzenie nowego w�z�a z warto�ci�
                myList.AddLast(newNode);
                txtInput.Clear(); // Czy�cimy pole tekstowe
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        // Usuwa pierwszy element z listy
        private void btnRemoveFirst_Click(object sender, EventArgs e)
        {
            myList.RemoveFirst();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        // Usuwa ostatni element z listy
        private void btnRemoveLast_Click(object sender, EventArgs e)
        {
            myList.RemoveLast();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private string GetListContent()
        {
            var content = new StringBuilder();
            Node current = myList.Head;
            while (current != null)
            {
                content.Append("[ ");
                content.Append(DisplayNodeData(current));
                content.Append(" ] -> ");
                current = current.Next;
            }
            content.Append("null");
            return content.ToString();
        }

        private string DisplayNodeData(Node node)
        {
            return node.Data.ToString();
        }
    }
}
