﻿namespace drzewoRozpinajace
{
    public class NodeG
    {
        public int data {  get; set; }

        public NodeG(int liczba)
        {
            this.data = liczba;
        }

        public override string ToString()
        {
            return this.data.ToString();
        }
    }
}
