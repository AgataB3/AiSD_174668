﻿namespace drzewoRozpinajace
{
    public class Edge
    {
        public NodeG start {  get; set; }
        public NodeG end { get; set; }
        public int weight { get; set; }

        public Edge(NodeG start, NodeG end, int weight)
        {
            this.start = start;
            this.end = end;
            this.weight = weight;
        }
    }
}
