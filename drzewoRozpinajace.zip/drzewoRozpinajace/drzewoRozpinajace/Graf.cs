﻿using System.Xml.Linq;

namespace drzewoRozpinajace
{
    public class Graf
    {
        public List<NodeG> nodes {  get; set; }
        public List<Edge> edges { get; set; }
        public Graf podgraf;
        public List<Graf> podgrafy;

        public Graf()
        {
            this.nodes = new List<NodeG>();
            this.edges = new List<Edge>();
        }

        public Graf(Edge k)
        {
            this.nodes = new List<NodeG>() { k.start, k.end };
            this.edges = new List<Edge> { k };
        }

        public void addNode(NodeG node)
        {
            nodes.Add(node);
        }
        public void addEdge(Edge edge)
        {
            edges.Add(edge);
        }

        public void Kruskal()
        {
            var posortowane = edges.OrderBy(x => x.weight).ToList();
            this.podgraf = new Graf(posortowane[0]);
            this.podgrafy = new List<Graf>();
            for (int i = 1; i < posortowane.Count; i++)
            {
                KruskalWykonaj(posortowane[i]);
            }
        }
        private void KruskalWykonaj(Edge k)
        {
            var x = podgraf.SprawdzKrawedz(k);
            if (x == 0)
            {
                return;
            }
            else if (x == 1)
            {
                var node = this.podgraf.nodes.Contains(k.start) ? k.end : k.start;
                this.podgraf.nodes.Add(node);
                this.podgraf.edges.Add(k);
            }
            else if (x == 2)
            {
                podgrafy.Add(new Graf(k));
            }
            foreach (var item in podgrafy.ToArray())
            {
                if ((podgraf.nodes.Contains(k.start) && item.nodes.Contains(k.end)) || (podgraf.nodes.Contains(k.end) && item.nodes.Contains(k.start)))
                {
                    podgraf.Polacz(item);
                    podgrafy.Remove(item);
                    podgraf.nodes = podgraf.nodes.Distinct().ToList();
                }
            }
        }
        public int SprawdzKrawedz(Edge k)
        {
            int wynik = 0;

            if (!this.nodes.Contains(k.start))
                wynik++;
            if (!this.nodes.Contains(k.end))
                wynik++;

            return wynik;
        }
        public void Polacz(Graf g)
        {
            this.nodes.AddRange(g.nodes);
            this.edges.AddRange(g.edges);
        }
    }
}
