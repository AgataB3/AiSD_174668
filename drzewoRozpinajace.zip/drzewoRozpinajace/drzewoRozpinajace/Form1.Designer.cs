﻿namespace drzewoRozpinajace
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelGraph = new Panel();
            buttonDrzewo = new Button();
            listViewDrzewo = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            panelDrzewo = new Panel();
            SuspendLayout();
            // 
            // panelGraph
            // 
            panelGraph.Location = new Point(12, 21);
            panelGraph.Margin = new Padding(3, 2, 3, 2);
            panelGraph.Name = "panelGraph";
            panelGraph.Size = new Size(396, 332);
            panelGraph.TabIndex = 0;
            // 
            // buttonDrzewo
            // 
            buttonDrzewo.Location = new Point(414, 21);
            buttonDrzewo.Margin = new Padding(3, 2, 3, 2);
            buttonDrzewo.Name = "buttonDrzewo";
            buttonDrzewo.Size = new Size(184, 45);
            buttonDrzewo.TabIndex = 1;
            buttonDrzewo.Text = "Stwórz drzewo rozpinające";
            buttonDrzewo.UseVisualStyleBackColor = true;
            buttonDrzewo.Click += buttonDrzewo_Click;
            // 
            // listViewDrzewo
            // 
            listViewDrzewo.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3 });
            listViewDrzewo.Location = new Point(414, 79);
            listViewDrzewo.Margin = new Padding(3, 2, 3, 2);
            listViewDrzewo.Name = "listViewDrzewo";
            listViewDrzewo.Size = new Size(184, 242);
            listViewDrzewo.TabIndex = 2;
            listViewDrzewo.UseCompatibleStateImageBehavior = false;
            listViewDrzewo.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Start";
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Koniec";
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Waga";
            // 
            // panelDrzewo
            // 
            panelDrzewo.Location = new Point(604, 21);
            panelDrzewo.Name = "panelDrzewo";
            panelDrzewo.Size = new Size(414, 335);
            panelDrzewo.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1034, 377);
            Controls.Add(panelDrzewo);
            Controls.Add(listViewDrzewo);
            Controls.Add(buttonDrzewo);
            Controls.Add(panelGraph);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Panel panelGraph;
        private Button buttonDrzewo;
        private ListView listViewDrzewo;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private Panel panelDrzewo;
    }
}
