namespace drzewoRozpinajace
{
    public partial class Form1 : Form
    {
        private Graf graf = new Graf();
        private Dictionary<NodeG, Point> nodePositions;
        private Dictionary<NodeG, Point> nodePositionsDrzewo;
        public Form1()
        {
            InitializeComponent();

            NodeG A = new NodeG(0);
            NodeG B = new NodeG(1);
            NodeG C = new NodeG(2);
            NodeG D = new NodeG(3);
            NodeG E = new NodeG(4);
            NodeG F = new NodeG(5);
            NodeG G = new NodeG(6);
            NodeG H = new NodeG(7);
            Edge e1 = new Edge(A, B, 5);
            Edge e2 = new Edge(A, G, 3);
            Edge e3 = new Edge(A, D, 9);
            Edge e4 = new Edge(B, C, 9);
            Edge e5 = new Edge(B, F, 6);
            Edge e6 = new Edge(B, E, 8);
            Edge e7 = new Edge(B, H, 7);
            Edge e8 = new Edge(C, D, 9);
            Edge e9 = new Edge(C, E, 4);
            Edge e10 = new Edge(C, G, 5);
            Edge e11 = new Edge(C, H, 3);
            Edge e12 = new Edge(D, G, 6);
            Edge e13 = new Edge(E, F, 2);
            Edge e14 = new Edge(E, G, 1);
            Edge e15 = new Edge(F, G, 6);
            Edge e16 = new Edge(G, H, 9);

            graf.addNode(A);
            graf.addNode(B);
            graf.addNode(C);
            graf.addNode(D);
            graf.addNode(E);
            graf.addNode(F);
            graf.addNode(G);
            graf.addNode(H);
            graf.addEdge(e1);
            graf.addEdge(e2);
            graf.addEdge(e3);
            graf.addEdge(e4);
            graf.addEdge(e5);
            graf.addEdge(e6);
            graf.addEdge(e7);
            graf.addEdge(e8);
            graf.addEdge(e9);
            graf.addEdge(e10);
            graf.addEdge(e11);
            graf.addEdge(e12);
            graf.addEdge(e13);
            graf.addEdge(e14);
            graf.addEdge(e15);
            graf.addEdge(e16);

            InitializeNodePositions();

            panelGraph.Paint += PanelGraph_Paint;
        }

        private void InitializeNodePositions()
        {
            nodePositions = new Dictionary<NodeG, Point>();
            int centerX = panelGraph.Width / 2;
            int centerY = panelGraph.Height / 2;
            int radius = Math.Min(panelGraph.Width, panelGraph.Height) / 2 - 50;

            var nodes = graf.nodes;
            int nodeCount = nodes.Count;

            for (int i = 0; i < nodeCount; i++)
            {
                double angle = 2 * Math.PI * i / nodeCount;
                int x = centerX + (int)(radius * Math.Cos(angle));
                int y = centerY + (int)(radius * Math.Sin(angle));
                nodePositions[nodes[i]] = new Point(x, y);
            }
        }

        private void PanelGraph_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen edgePen = new Pen(Color.Black, 2);
            Brush nodeBrush = Brushes.LightBlue;
            Brush textBrush = Brushes.Black;
            Font font = new Font("Arial", 12);

            foreach (var edge in graf.edges)
            {
                Point start = nodePositions[edge.start];
                Point end = nodePositions[edge.end];
                g.DrawLine(edgePen, start, end);

                int weightX = (start.X + end.X) / 2;
                int weightY = (start.Y + end.Y) / 2;
                g.DrawString(edge.weight.ToString(), font, textBrush, weightX, weightY);
            }

            foreach (var node in graf.nodes)
            {
                Point position = nodePositions[node];
                Rectangle nodeRect = new Rectangle(position.X - 15, position.Y - 15, 30, 30);
                g.FillEllipse(nodeBrush, nodeRect);
                g.DrawEllipse(Pens.Black, nodeRect);

                g.DrawString(node.data.ToString(), font, textBrush, position.X - 10, position.Y - 10);
            }
        }

        private void buttonDrzewo_Click(object sender, EventArgs e)
        {
            graf.Kruskal();
            listViewDrzewo.Items.Clear();
            var kraw = graf.podgraf.edges;
            foreach (var item in kraw)
            {
                var row = new string[] { item.start.ToString(), item.end.ToString(), item.weight.ToString() };
                var lvi = new ListViewItem(row);
                listViewDrzewo.Items.Add(lvi);
            }

            InitializeNodePositionsDrzewo();
            panelDrzewo.Paint += PanelDrzewo_Paint;
            panelDrzewo.Invalidate();
        }
        private void InitializeNodePositionsDrzewo()
        {
            nodePositionsDrzewo = new Dictionary<NodeG, Point>();
            int centerX = panelDrzewo.Width / 2;
            int centerY = panelDrzewo.Height / 2;
            int radius = Math.Min(panelDrzewo.Width, panelDrzewo.Height) / 2 - 50;

            var nodes = graf.podgraf.nodes;
            int nodeCount = nodes.Count;

            for (int i = 0; i < nodeCount; i++)
            {
                double angle = 2 * Math.PI * i / nodeCount;
                int x = centerX + (int)(radius * Math.Cos(angle));
                int y = centerY + (int)(radius * Math.Sin(angle));
                nodePositionsDrzewo[nodes[i]] = new Point(x, y);
            }
        }
        private void PanelDrzewo_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen edgePen = new Pen(Color.Black, 2);
            Brush nodeBrush = Brushes.LightBlue;
            Brush textBrush = Brushes.Black;
            Font font = new Font("Arial", 12);

            foreach (var edge in graf.podgraf.edges)
            {
                Point start = nodePositions[edge.start];
                Point end = nodePositions[edge.end];
                g.DrawLine(edgePen, start, end);

                int weightX = (start.X + end.X) / 2;
                int weightY = (start.Y + end.Y) / 2;
                g.DrawString(edge.weight.ToString(), font, textBrush, weightX, weightY);
            }

            foreach (var node in graf.podgraf.nodes)
            {
                Point position = nodePositions[node];
                Rectangle nodeRect = new Rectangle(position.X - 15, position.Y - 15, 30, 30);
                g.FillEllipse(nodeBrush, nodeRect);
                g.DrawEllipse(Pens.Black, nodeRect);

                g.DrawString(node.data.ToString(), font, textBrush, position.X - 10, position.Y - 10);
            }
        }
    }
}
