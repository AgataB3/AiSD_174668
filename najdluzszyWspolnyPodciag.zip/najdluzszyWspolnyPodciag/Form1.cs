using System.Globalization;

namespace najdluzszyWspolnyPodciag
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void wykonaj_Click(object sender, EventArgs e)
        {
            String napis1 = textBox1.Text;
            String napis2 = textBox2.Text;

            if (string.IsNullOrEmpty(napis1) || string.IsNullOrEmpty(napis2))
            {
                textBox3.Text = "0";
                return;
            }

            int n = napis1.Length;
            int m = napis2.Length;

            int[,] tab = new int[n+1, m+1];

            for(int i = 0; i < n + 1; i++)
            {
                tab[i,0] = 0;
            }
            for(int j = 0; j < m + 1; j++)
            {
                tab[0, j] = 0;
            }
            for(int i = 1; i < n+1; i++)
            {
                for(int j = 1; j < m+1; j++)
                {
                    if (napis1[i - 1] == napis2[j - 1]) tab[i, j] = tab[i - 1, j - 1] + 1;
                    else tab[i, j] = Math.Max(tab[i - 1, j], tab[i, j - 1]);
                }
            }

            int x = n-1, y = m-1;
            String wynik = "";
            while (x != 0 && y != 0) {
                if (tab[x-1, y] == tab[x, y])
                {
                    x--;
                }
                else if (tab[x, y-1] == tab[x, y])
                {
                    y--;
                }
                else
                {
                    wynik += napis1[x - 1];
                    x--;
                    y--;
                }
            }
            wynik = new string(wynik.Reverse().ToArray());
            textBox3.Text = tab[n, m]+" "+wynik;
        }
    }
}