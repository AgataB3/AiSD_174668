using System.Globalization;

namespace najdluzszyWspolnyPodciag
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void wykonaj_Click(object sender, EventArgs e)
        {
            String napis1 = textBox1.Text;
            String napis2 = textBox2.Text;
            int n = napis1.Length;
            int m = napis2.Length;

            int[,] tab = new int[n, m];

            for(int i = 0; i < n; i++)
            {
                tab[i,0] = 0;
            }
            for(int j = 0; j < m; j++)
            {
                tab[0, j] = 0;
            }
            for(int i = 1; i < n; i++)
            {
                for(int j = 1; j < m; j++)
                {
                    if (napis1[i] == napis2[j]) tab[i, j] = tab[i - 1, j - 1] + 1;
                    else tab[i, j] = Math.Max(tab[i - 1, j], tab[i, j - 1]);
                }
            }

            int x = n-1, y = m-1, zm = 0;
            String[] wynik = new String[tab[n-1, m-1]];
            while (wynik.Length < tab[n-1, m-1]) {
                if (tab[x-1, y] == tab[x, y])
                {
                    x--;
                }
                else if (tab[x, y-1] == tab[x, y])
                {
                    y--;
                }
                else
                {
                    wynik[zm] += napis1[x];
                    x--;
                    y--;
                    zm++;
                }
            }
            napis1 = Reverse(napis1);
            textBox3.Text = tab[n-1, m-1]+" "+napis1;
        }
        public string Reverse(string text)
        {
            char[] cArray = text.ToCharArray();
            string reverse = String.Empty;
            for (int i = cArray.Length - 1; i > -1; i--)
            {
                reverse += cArray[i];
            }
            return reverse;
        }
    }
}