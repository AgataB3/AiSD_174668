﻿namespace NodeList
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtInput = new TextBox();
            btnAddFirst = new Button();
            btnAddLast = new Button();
            btnRemoveFirst = new Button();
            btnRemoveLast = new Button();
            txtDisplay = new TextBox();
            count_display = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtInput
            // 
            txtInput.Location = new Point(46, 65);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(624, 27);
            txtInput.TabIndex = 0;
            // 
            // btnAddFirst
            // 
            btnAddFirst.Location = new Point(46, 120);
            btnAddFirst.Name = "btnAddFirst";
            btnAddFirst.Size = new Size(152, 62);
            btnAddFirst.TabIndex = 1;
            btnAddFirst.Text = "Add First";
            btnAddFirst.UseVisualStyleBackColor = true;
            btnAddFirst.Click += btnAddFirst_Click;
            // 
            // btnAddLast
            // 
            btnAddLast.Location = new Point(205, 120);
            btnAddLast.Name = "btnAddLast";
            btnAddLast.Size = new Size(151, 62);
            btnAddLast.TabIndex = 2;
            btnAddLast.Text = "Add Last";
            btnAddLast.UseVisualStyleBackColor = true;
            btnAddLast.Click += btnAddLast_Click;
            // 
            // btnRemoveFirst
            // 
            btnRemoveFirst.Location = new Point(362, 120);
            btnRemoveFirst.Name = "btnRemoveFirst";
            btnRemoveFirst.Size = new Size(153, 62);
            btnRemoveFirst.TabIndex = 3;
            btnRemoveFirst.Text = "Remove First";
            btnRemoveFirst.UseVisualStyleBackColor = true;
            btnRemoveFirst.Click += btnRemoveFirst_Click;
            // 
            // btnRemoveLast
            // 
            btnRemoveLast.Location = new Point(521, 120);
            btnRemoveLast.Name = "btnRemoveLast";
            btnRemoveLast.Size = new Size(149, 62);
            btnRemoveLast.TabIndex = 4;
            btnRemoveLast.Text = "Remove Last";
            btnRemoveLast.UseVisualStyleBackColor = true;
            btnRemoveLast.Click += btnRemoveLast_Click;
            // 
            // txtDisplay
            // 
            txtDisplay.Location = new Point(46, 216);
            txtDisplay.Multiline = true;
            txtDisplay.Name = "txtDisplay";
            txtDisplay.Size = new Size(624, 118);
            txtDisplay.TabIndex = 5;
            // 
            // count_display
            // 
            count_display.AutoSize = true;
            count_display.Location = new Point(46, 337);
            count_display.Name = "count_display";
            count_display.Size = new Size(144, 20);
            count_display.TabIndex = 6;
            count_display.Text = "Liczba elementów: 0";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 42);
            label1.Name = "label1";
            label1.Size = new Size(367, 20);
            label1.TabIndex = 7;
            label1.Text = "Wpisz liczbę a następnie kliknij Add First lub Add Last:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(count_display);
            Controls.Add(txtDisplay);
            Controls.Add(btnRemoveLast);
            Controls.Add(btnRemoveFirst);
            Controls.Add(btnAddLast);
            Controls.Add(btnAddFirst);
            Controls.Add(txtInput);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtInput;
        private Button btnAddFirst;
        private Button btnAddLast;
        private Button btnRemoveFirst;
        private Button btnRemoveLast;
        private TextBox txtDisplay;
        private Label count_display;
        private Label label1;
    }
}
