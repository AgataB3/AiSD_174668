using System.Text;

namespace NodeList
{
    public partial class Form1 : Form
    {
        private List myList;
        
        public Form1()
        {
            InitializeComponent();
            myList = new List();
        }
        private void btnAddFirst_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value))
            {
                Node newNode = new Node(value);
                myList.AddFirst(newNode);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnAddLast_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int value))
            {
                Node newNode = new Node(value);
                myList.AddLast(newNode);
                txtInput.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
            }
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnRemoveFirst_Click(object sender, EventArgs e)
        {
            myList.RemoveFirst();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private void btnRemoveLast_Click(object sender, EventArgs e)
        {
            myList.RemoveLast();
            txtDisplay.Text = GetListContent();
            count_display.Text = $"Liczba element�w: {myList.Count}";
        }

        private string GetListContent()
        {
            var content = new StringBuilder();
            Node current = myList.head;
            while (current != null)
            {
                content.Append("[ ");
                content.Append(DisplayNodeData(current));
                content.Append(" ] -> ");
                current = current.Next;
            }
            content.Append("null");
            return content.ToString();
        }

        private string DisplayNodeData(Node node)
        {
            return node.Data.ToString();
        }
    }
}
