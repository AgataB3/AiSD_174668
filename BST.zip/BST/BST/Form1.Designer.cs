﻿namespace BST
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BSTInput = new TextBox();
            btBSTInput = new Button();
            BSTRemove = new TextBox();
            btBSTRemove = new Button();
            treeView1 = new TreeView();
            tBPre = new TextBox();
            tBIn = new TextBox();
            tBPost = new TextBox();
            btPre = new Button();
            btIn = new Button();
            btPost = new Button();
            SuspendLayout();
            // 
            // BSTInput
            // 
            BSTInput.Location = new Point(22, 26);
            BSTInput.Name = "BSTInput";
            BSTInput.Size = new Size(191, 27);
            BSTInput.TabIndex = 0;
            // 
            // btBSTInput
            // 
            btBSTInput.Location = new Point(22, 59);
            btBSTInput.Name = "btBSTInput";
            btBSTInput.Size = new Size(190, 51);
            btBSTInput.TabIndex = 1;
            btBSTInput.Text = "Dodaj do drzewka BST";
            btBSTInput.UseVisualStyleBackColor = true;
            btBSTInput.Click += btBSTInput_Click;
            // 
            // BSTRemove
            // 
            BSTRemove.Location = new Point(22, 149);
            BSTRemove.Name = "BSTRemove";
            BSTRemove.Size = new Size(191, 27);
            BSTRemove.TabIndex = 2;
            // 
            // btBSTRemove
            // 
            btBSTRemove.Location = new Point(22, 182);
            btBSTRemove.Name = "btBSTRemove";
            btBSTRemove.Size = new Size(190, 54);
            btBSTRemove.TabIndex = 3;
            btBSTRemove.Text = "Usuń element o podanej wartości";
            btBSTRemove.UseVisualStyleBackColor = true;
            btBSTRemove.Click += btBSTRemove_Click;
            // 
            // treeView1
            // 
            treeView1.Location = new Point(219, 26);
            treeView1.Name = "treeView1";
            treeView1.Size = new Size(569, 328);
            treeView1.TabIndex = 4;
            // 
            // tBPre
            // 
            tBPre.Location = new Point(22, 375);
            tBPre.Name = "tBPre";
            tBPre.Size = new Size(249, 27);
            tBPre.TabIndex = 5;
            // 
            // tBIn
            // 
            tBIn.Location = new Point(277, 375);
            tBIn.Name = "tBIn";
            tBIn.Size = new Size(269, 27);
            tBIn.TabIndex = 6;
            // 
            // tBPost
            // 
            tBPost.Location = new Point(552, 375);
            tBPost.Name = "tBPost";
            tBPost.Size = new Size(236, 27);
            tBPost.TabIndex = 7;
            // 
            // btPre
            // 
            btPre.Location = new Point(22, 408);
            btPre.Name = "btPre";
            btPre.Size = new Size(249, 30);
            btPre.TabIndex = 8;
            btPre.Text = "PreOrder";
            btPre.UseVisualStyleBackColor = true;
            btPre.Click += btPre_Click;
            // 
            // btIn
            // 
            btIn.Location = new Point(277, 406);
            btIn.Name = "btIn";
            btIn.Size = new Size(269, 32);
            btIn.TabIndex = 9;
            btIn.Text = "InOrder";
            btIn.UseVisualStyleBackColor = true;
            btIn.Click += btIn_Click;
            // 
            // btPost
            // 
            btPost.Location = new Point(552, 406);
            btPost.Name = "btPost";
            btPost.Size = new Size(236, 32);
            btPost.TabIndex = 10;
            btPost.Text = "PostOrder";
            btPost.UseVisualStyleBackColor = true;
            btPost.Click += btPost_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btPost);
            Controls.Add(btIn);
            Controls.Add(btPre);
            Controls.Add(tBPost);
            Controls.Add(tBIn);
            Controls.Add(tBPre);
            Controls.Add(treeView1);
            Controls.Add(btBSTRemove);
            Controls.Add(BSTRemove);
            Controls.Add(btBSTInput);
            Controls.Add(BSTInput);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox BSTInput;
        private Button btBSTInput;
        private TextBox BSTRemove;
        private Button btBSTRemove;
        private TreeView treeView1;
        private TextBox tBPre;
        private TextBox tBIn;
        private TextBox tBPost;
        private Button btPre;
        private Button btIn;
        private Button btPost;
    }
}
