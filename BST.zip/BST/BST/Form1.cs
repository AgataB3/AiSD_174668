using System.Xml.Linq;

namespace BST
{
    public partial class Form1 : Form
    {

        BST tree1 = new BST();
        public Form1()
        {
            InitializeComponent();
        }
        void ShowNode(NodeT nodeT, TreeNode treeNode)
        {
            if (nodeT == null) return;
            treeNode.Text += nodeT.data;
            if (nodeT.lewe != null)
            {
                ShowNode(nodeT.lewe, treeNode.Nodes.Add("Lewe: "));
            }
            if (nodeT.prawe != null)
            {
                ShowNode(nodeT.prawe, treeNode.Nodes.Add("Prawe: "));
            }

        }
        void Show(BST tree)
        {
            treeView1.Nodes.Clear();
            ShowNode(tree.root, treeView1.Nodes.Add("Korzen: "));
            treeView1.ExpandAll();
        }

        private void btBSTInput_Click(object sender, EventArgs e)
        {
            if (int.TryParse(BSTInput.Text, out int value))
            {
                var liczba = int.Parse(BSTInput.Text);
                tree1.Add(liczba);
                BSTInput.Clear();
                treeView1.Nodes.Clear();
                Show(tree1);
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
                BSTInput.Clear();
            }
        }

        void PreOrder(NodeT x)
        {
            if (x == null)
                return;
            tBPre.Text += x.data.ToString();
            tBPre.Text += " ";
            PreOrder(x.lewe);
            PreOrder(x.prawe);
        }

        void InOrder(NodeT x)
        {
            if (x == null)
                return;
            InOrder(x.lewe);
            tBIn.Text += x.data.ToString();
            tBIn.Text += " ";
            InOrder(x.prawe);
        }

        void PostOrder(NodeT x)
        {
            if (x == null)
                return;

            PostOrder(x.lewe);
            PostOrder(x.prawe);
            tBPost.Text += x.data.ToString();
            tBPost.Text += " ";
        }
        private void btPre_Click(object sender, EventArgs e)
        {
            tBPre.Clear();
            PreOrder(tree1.root);
        }

        private void btIn_Click(object sender, EventArgs e)
        {
            tBIn.Clear();
            InOrder(tree1.root);
        }

        private void btPost_Click(object sender, EventArgs e)
        {
            tBPost.Clear();
            PostOrder(tree1.root);
        }

        public NodeT Find(NodeT x, int liczba)
        {
            if (x == null || x.data == liczba) return x;
            if (liczba < x.data)
            {
                return Find(x.lewe, liczba);
            }
            else
            {
                return Find(x.prawe, liczba);
            }
        }

        private void btBSTRemove_Click(object sender, EventArgs e)
        {
            if (int.TryParse(BSTRemove.Text, out int value))
            {
                var liczba = int.Parse(BSTRemove.Text);
                NodeT x = Find(tree1.root, liczba);
                tree1.RemoveElement(x);
                BSTRemove.Clear();
                treeView1.Nodes.Clear();
                Show(tree1);
            }
            else
            {
                MessageBox.Show("Please enter a valid integer.");
                BSTRemove.Clear();
            }
        }
    }
}
