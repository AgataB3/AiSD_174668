using System.Xml.Linq;

namespace Dijkstra
{
    public partial class Form1 : Form
    {
        private Graf graf = new Graf();
        private Dictionary<Node, Point> nodePositions;
        public Form1()
        {
            InitializeComponent();

            Node A = new Node(0);
            Node B = new Node(1);
            Node C = new Node(2);
            Node D = new Node(3);
            Node E = new Node(4);
            Node F = new Node(5);

            Edge e1 = new Edge(A, B, 3);
            Edge e2 = new Edge(A, E, 3);
            Edge e3 = new Edge(A, F, 6);
            Edge e4 = new Edge(B, C, 1);
            Edge e5 = new Edge(B, D, 3);
            Edge e6 = new Edge(C, D, 3);
            Edge e7 = new Edge(C, F, 1);
            Edge e8 = new Edge(D, F, 1);
            Edge e9 = new Edge(E, F, 2);

            graf.addNode(A);
            graf.addNode(B);
            graf.addNode(C);
            graf.addNode(D);
            graf.addNode(E);
            graf.addNode(F);
            graf.addEdge(e1);
            graf.addEdge(e2);
            graf.addEdge(e3);
            graf.addEdge(e4);
            graf.addEdge(e5);
            graf.addEdge(e6);
            graf.addEdge(e7);
            graf.addEdge(e8);
            graf.addEdge(e9);

            InitializeNodePositions();

            panelGraph.Paint += PanelGraph_Paint;
        }

        private void buttonDijkstra_Click(object sender, EventArgs e)
        {
            graf.Dijkstra(graf.nodes.First());
            var dict = graf.tabela;
            foreach (var item in dict)
            {
                var row = new string[] { item.Key.data.ToString(), item.Value.ToString() };
                var lvi = new ListViewItem(row);
                listViewDijkstra.Items.Add(lvi);
            }
        }

        private void InitializeNodePositions()
        {
            nodePositions = new Dictionary<Node, Point>();
            int centerX = panelGraph.Width / 2;
            int centerY = panelGraph.Height / 2;
            int radius = Math.Min(panelGraph.Width, panelGraph.Height) / 2 - 50;

            var nodes = graf.nodes;
            int nodeCount = nodes.Count;

            for (int i = 0; i < nodeCount; i++)
            {
                double angle = 2 * Math.PI * i / nodeCount;
                int x = centerX + (int)(radius * Math.Cos(angle));
                int y = centerY + (int)(radius * Math.Sin(angle));
                nodePositions[nodes[i]] = new Point(x, y);
            }
        }

        private void PanelGraph_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen edgePen = new Pen(Color.Black, 2);
            Brush nodeBrush = Brushes.LightBlue;
            Brush textBrush = Brushes.Black;
            Font font = new Font("Arial", 12);

            foreach (var edge in graf.edges)
            {
                Point start = nodePositions[edge.start];
                Point end = nodePositions[edge.end];
                g.DrawLine(edgePen, start, end);

                int weightX = (start.X + end.X) / 2;
                int weightY = (start.Y + end.Y) / 2;
                g.DrawString(edge.weight.ToString(), font, textBrush, weightX, weightY);
            }

            foreach (var node in graf.nodes)
            {
                Point position = nodePositions[node];
                Rectangle nodeRect = new Rectangle(position.X - 15, position.Y - 15, 30, 30);
                g.FillEllipse(nodeBrush, nodeRect);
                g.DrawEllipse(Pens.Black, nodeRect);

                g.DrawString(node.data.ToString(), font, textBrush, position.X - 10, position.Y - 10);
            }
        }
    }
}
