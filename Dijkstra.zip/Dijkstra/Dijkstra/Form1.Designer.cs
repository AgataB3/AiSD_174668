﻿namespace Dijkstra
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelGraph = new Panel();
            listViewDijkstra = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            buttonDijkstra = new Button();
            SuspendLayout();
            // 
            // panelGraph
            // 
            panelGraph.Location = new Point(12, 12);
            panelGraph.Name = "panelGraph";
            panelGraph.Size = new Size(410, 360);
            panelGraph.TabIndex = 0;
            // 
            // listViewDijkstra
            // 
            listViewDijkstra.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2 });
            listViewDijkstra.Location = new Point(428, 88);
            listViewDijkstra.Name = "listViewDijkstra";
            listViewDijkstra.Size = new Size(230, 213);
            listViewDijkstra.TabIndex = 1;
            listViewDijkstra.UseCompatibleStateImageBehavior = false;
            listViewDijkstra.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Węzeł docelowy";
            columnHeader1.Width = 113;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Prev - Odległość";
            columnHeader2.Width = 113;
            // 
            // buttonDijkstra
            // 
            buttonDijkstra.Location = new Point(481, 48);
            buttonDijkstra.Name = "buttonDijkstra";
            buttonDijkstra.Size = new Size(123, 34);
            buttonDijkstra.TabIndex = 2;
            buttonDijkstra.Text = "Dijkstra dla węzła 0";
            buttonDijkstra.UseVisualStyleBackColor = true;
            buttonDijkstra.Click += buttonDijkstra_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(674, 381);
            Controls.Add(buttonDijkstra);
            Controls.Add(listViewDijkstra);
            Controls.Add(panelGraph);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Panel panelGraph;
        private ListView listViewDijkstra;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private Button buttonDijkstra;
    }
}
