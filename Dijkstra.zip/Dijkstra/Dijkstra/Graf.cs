﻿using System.Xml.Linq;

namespace Dijkstra
{
    public class Graf
    {
        public List<Node> nodes { get; set; }
        public List<Edge> edges { get; set; }

        public Dictionary<Node, Para> tabela;
        public List<Node> odwiedzone;

        public Graf()
        {
            this.nodes = new List<Node>();
            this.edges = new List<Edge>();
            this.tabela = new Dictionary<Node, Para>();
            this.odwiedzone = new List<Node>();
        }

        public void addNode(Node node)
        {
            nodes.Add(node);
        }
        public void addEdge(Edge edge)
        {
            edges.Add(edge);
        }

        public void Dijkstra(Node n)
        {

            tabela.Add(n, new Para(null, 0));
            for (int i = 1; i < nodes.Count; i++)
            {
                tabela.Add(nodes[i], new Para(null, int.MaxValue));
            }
            while (this.odwiedzone.Count < this.nodes.Count)
            {
                var element = tabela.OrderBy(x => x.Value.odleglosc).FirstOrDefault(x => !this.odwiedzone.Contains(x.Key));
                if (element.Key == null)
                {
                    break;
                }
                else
                {
                    Dijkstra_wykonaj(element.Key, element.Value.odleglosc);
                }
            }
        }

        private void Dijkstra_wykonaj(Node n, int odl)
        {
            if (odwiedzone.Contains(n))
            {
                return;
            }
            odwiedzone.Add(n);
            List<Edge> krawedzieWezla = ZnajdzKrawedzie(n);
            foreach (var krawedz in krawedzieWezla)
            {
                Node drugi = krawedz.ZnajdzDrugi(n);
                var trasa = krawedz.weight + odl;
                if (trasa < tabela[drugi].odleglosc)
                {
                    tabela[drugi].prev = n;
                    tabela[drugi].odleglosc = trasa;
                }
            }

        }

        public List<Edge> ZnajdzKrawedzie(Node n)
        {
            return this.edges.Where(k => k.start == n || k.end == n).ToList();
        }
    }
}
