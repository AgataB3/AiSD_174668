﻿namespace Dijkstra
{
    public class Edge
    {
        public Node start { get; set; }
        public Node end { get; set; }
        public int weight { get; set; }

        public Edge(Node start, Node end, int weight)
        {
            this.start = start;
            this.end = end;
            this.weight = weight;
        }
        public Node ZnajdzDrugi(Node n)
        {
            return n == this.start ? this.end : this.start;
        }
    }
}
