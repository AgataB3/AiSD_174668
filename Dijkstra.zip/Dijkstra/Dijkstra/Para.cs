﻿namespace Dijkstra
{
    public class Para
    {
        public Node prev;
        public int odleglosc;

        public Para(Node p, int odl)
        {
            this.prev = p;
            this.odleglosc = odl;
        }

        public override string ToString()
        {
            if (this.prev == null)
            {
                return $"null - {this.odleglosc}";
            }
            else
            {
                return $"{this.prev.ToString()} - {this.odleglosc}";
            }
        }
    }
}
