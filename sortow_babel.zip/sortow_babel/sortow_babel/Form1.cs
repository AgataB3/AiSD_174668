using System;
using System.Windows.Forms;

namespace sortow_babel
{
    public partial class Form1 : Form
    {
        private int[] tablica = { 5, 6, 4, 1, 2 , 3};

        public Form1()
        {
            InitializeComponent();
            Wyswietl(tablica, listBox1);
        }

        private void Wyswietl(int[] tablica, ListBox listBox)
        {
            listBox.Items.Clear();
            for (int i = 0; i < tablica.Length; i++)
            {
                listBox.Items.Add(tablica[i]);
            }
        }

        private void Sortowanie(int[] tablica)
        {
            int zm;
            for (int i = 0; i < tablica.Length - 1; i++)
            {
                for (int j = 0; j < tablica.Length - 1 - i; j++)
                {
                    if (tablica[j] > tablica[j + 1])
                    {
                        zm = tablica[j];
                        tablica[j] = tablica[j + 1];
                        tablica[j + 1] = zm;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sortowanie(tablica);
            Wyswietl(tablica, listBox2);
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
