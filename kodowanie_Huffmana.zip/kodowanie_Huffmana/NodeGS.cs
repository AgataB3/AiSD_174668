﻿namespace kodowanie_Huffmana
{
    internal class NodeGS : NodeG
    {
        char symbol;
    }
}
