﻿namespace kodowanie_Huffmana
{
    public class NodeGS : NodeG
    {
        public char Symbol { get; set; }
    }
}
