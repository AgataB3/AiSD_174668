namespace kodowanie_Huffmana
{
    public partial class Form1 : Form
    {

        private NodeG root;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Wprowad� tekst do zakodowania.", "B��d", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Dictionary<char, int> slownik = Czestosc(input);

            root = null;
            root = StworzDrzewo(slownik);

            Dictionary<char, string> kody = GenerujKody(root);
            listBox1.Items.Clear();
            foreach (var item in kody)
            {
                listBox1.Items.Add($"{item.Key}: {item.Value}");
            }
            this.Invalidate();
        }
        public Dictionary<char, int> Czestosc(string input)
        {
            Dictionary<char, int> slownik = new Dictionary<char, int>();
            foreach (char l in input){
                if (!slownik.ContainsKey(l))
                {
                    slownik.Add(l, 1);
                }
                else
                {
                    slownik[l]++;
                }
            }
            return slownik;
        }
        public NodeG StworzDrzewo(Dictionary<char, int> slownik)
        {
            List<NodeG> kolejka = new List<NodeG>();

            foreach (var item in slownik)
            {
                kolejka.Add(new NodeGS { Symbol = item.Key, Data = item.Value });
            }

            while (kolejka.Count > 1)
            {
                kolejka = kolejka.OrderBy(n => n.Data).ToList();

                NodeG lewe = kolejka[0];
                NodeG prawe = kolejka[1];
                kolejka.RemoveRange(0, 2);

                NodeG nowy = new NodeG
                {
                    Data = lewe.Data + prawe.Data,
                    Lewe = lewe,
                    Prawe = prawe
                };

                lewe.Rodzic = nowy;
                prawe.Rodzic = nowy;

                kolejka.Add(nowy);
            }
            return kolejka[0];
        }
        public Dictionary<char, string> GenerujKody(NodeG root)
        {
            Dictionary<char, string> kody = new Dictionary<char, string>();
            GenerujKodyRekurencyjnie(root, "", kody);
            return kody;
        }
        private void GenerujKodyRekurencyjnie(NodeG node, string kod, Dictionary<char, string> kody)
        {
            if (node == null) return;

            if (node is NodeGS leaf && leaf.Symbol != '\0')
            {
                kody[leaf.Symbol] = kod;
            }

            GenerujKodyRekurencyjnie(node.Lewe, kod + "0", kody);
            GenerujKodyRekurencyjnie(node.Prawe, kod + "1", kody);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (root != null)
            {
                Graphics g = e.Graphics;
                Pen pen = new Pen(Color.Black, 2);
                Brush brush = new SolidBrush(Color.Black);

                int width = this.ClientSize.Width;
                int height = this.ClientSize.Height;
                int startX = width / 2;
                int startY = 50;

                rysujWszystkieW�z�y(g, root, startX, startY, 100, pen, brush);
            }
        }

        private void rysujWszystkieW�z�y(Graphics g, NodeG node, int x, int y, int offsetX, Pen pen, Brush brush)
        {
            if (node == null) return;

            g.FillEllipse(brush, x - 20, y - 20, 40, 40);
            g.DrawEllipse(pen, x - 20, y - 20, 40, 40);
            g.DrawString(node is NodeGS n ? n.Symbol.ToString() : node.Data.ToString(), this.Font, Brushes.White, x - 10, y - 10);

            if (node.Lewe != null)
            {
                g.DrawLine(pen, x, y, x - offsetX, y + 60);
                rysujWszystkieW�z�y(g, node.Lewe, x - offsetX, y + 60, offsetX / 2, pen, brush);
            }

            if (node.Prawe != null)
            {
                g.DrawLine(pen, x, y, x + offsetX, y + 60);
                rysujWszystkieW�z�y(g, node.Prawe, x + offsetX, y + 60, offsetX / 2, pen, brush);
            }
        }
    }
}