namespace kodowanie_Huffmana
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            Dictionary<char, int> slownik = czestosc(input);
        }
        public Dictionary<char, int> czestosc(string input)
        {
            Dictionary<char, int> slownik = new Dictionary<char, int>();
            foreach (char l in input){
                if (!slownik.ContainsKey(l))
                {
                    slownik.Add(l, 1);
                }
                else
                {
                    slownik[l]++;
                }
            }
            return slownik;
        }
    }
}