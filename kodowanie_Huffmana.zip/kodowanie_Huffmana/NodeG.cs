﻿namespace kodowanie_Huffmana
{
    internal class NodeG
    {
        NodeG lewe;
        NodeG prawe;
        NodeG rodzic;
        int data; //czestosc


        //lista.OrderBy(n => n.data)
        //ThenBy(n => n.GetType()==typeof(NodeGS) ? 0 : 1)
    }
}
