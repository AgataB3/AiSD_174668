﻿namespace kodowanie_Huffmana
{
    public class NodeG
    {
        public NodeG Lewe { get; set; }
        public NodeG Prawe { get; set; }
        public NodeG Rodzic { get; set; }
        public int Data { get; set; } // częstotliwość
    }
}
